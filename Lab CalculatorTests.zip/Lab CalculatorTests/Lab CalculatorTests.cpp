#include "pch.h"
#include "CppUnitTest.h"
#include "../Lab Calculator/ButtonFactory.h"
#include "../Lab Calculator/CalculatorProcessor.h"
#include "../Lab Calculator/cMain.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace LabCalculatorTests
{
	TEST_CLASS(LabCalculatorTests)
	{
	public:
		

		//ButtonFactory
		TEST_METHOD(CreatingButtonOne)
		{
			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			
			
			wxButton* btn = factory.CreateAddButton(&window, 102, "1");

			Assert::AreEqual(btn->GetLabel(), "1");
		}
		TEST_METHOD(CreatingButtonTwo)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 103, "2");

			Assert::AreEqual(btn->GetLabel(), "2");
		}
		TEST_METHOD(CreatingButtonThree)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 104, "3");

			Assert::AreEqual(btn->GetLabel(), "3");
		}
		TEST_METHOD(CreatingButtonFour)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 105, "4");

			Assert::AreEqual(btn->GetLabel(), "4");
		}
		TEST_METHOD(CreatingButtonFive)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 106, "5");

			Assert::AreEqual(btn->GetLabel(), "5");
		}
		TEST_METHOD(CreatingButtonSix)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 107, "6");

			Assert::AreEqual(btn->GetLabel(), "6");
		}
		TEST_METHOD(CreatingButtonSeven)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 108, "7");

			Assert::AreEqual(btn->GetLabel(), "7");
		}
		TEST_METHOD(CreatingButtonEight)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 109, "8");

			Assert::AreEqual(btn->GetLabel(), "8");
		}
		TEST_METHOD(CreatingButtonNine)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 110, "9");

			Assert::AreEqual(btn->GetLabel(), "9");
		}
		TEST_METHOD(CreatingButtonZero)
		{


			wxFrame window(nullptr, wxID_ANY, "Calculator", wxPoint(30, 30), wxSize(490, 690));
			ButtonFactory factory;
			wxButton* btn = factory.CreateAddButton(&window, 101, "0");

			Assert::AreEqual(btn->GetLabel(), "0");
		}

		//CalculatorProcessor
		TEST_METHOD(TwoPlusThreeEqualFive)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("2", "3", "+");
			
			Assert::AreEqual(result.c_str(), "5");
		}
		TEST_METHOD(OneTimesNineEqualNine)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("1", "9", "*");

			Assert::AreEqual(result.c_str(), "9");

		}
		TEST_METHOD(SixDivTwoEqualThree)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("6", "2", "/");

			Assert::AreEqual(result.c_str(), "3");

		}
		TEST_METHOD(NineTimesNineEqualEightyOne)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("9", "9", "*");

			Assert::AreEqual(result.c_str(), "81");

		}
		TEST_METHOD(FivePlusFourEqualNine)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("5", "4", "+");

			Assert::AreEqual(result.c_str(), "9");

		}
		TEST_METHOD(TwoTimesSevenEqualFourthteen)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("2", "7", "*");

			Assert::AreEqual(result.c_str(), "14");

		}
		TEST_METHOD(TwoHundredTimesThreeHundredandFithyEqualseventhyThousen)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("200", "350", "*");

			Assert::AreEqual(result.c_str(), "70000");

		}
		TEST_METHOD(OnePlusZeroEqualOne)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("1", "0", "+");

			Assert::AreEqual(result.c_str(), "1");

		}
		TEST_METHOD(ThreeModSixTeenEqualThree)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("3", "16", "mod");

			Assert::AreEqual(result.c_str(), "3");

		}
		TEST_METHOD(ThreeMinusThreeEqualThree)
		{

			Processor* cal = Processor::GetInstance();
			std::string result = cal->Calculation("3", "3", "-");

			Assert::AreEqual(result.c_str(), "0");

		}
		
	};
}
